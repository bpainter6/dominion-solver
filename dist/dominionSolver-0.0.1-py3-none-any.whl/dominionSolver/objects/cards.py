# -*- coding: utf-8 -*-
"""
Created on Mon Jul 11 21:52:13 2022

@author: 17066
"""

import numpy as np

class _Card():
    pass

class _Adventurer(_Card):
	pass

class _Bureaucrat(_Card):
	pass

class _Cellar(_Card):
	pass

class _Chancellor(_Card):
	pass

class _Chapel(_Card):
	pass

class _Council_room(_Card):
	pass

class _Copper(_Card):
	pass

class _Feast(_Card):
	pass

class _Festival(_Card):
	pass

class _Laboratory(_Card):
	pass

class _Library(_Card):
	pass

class _Market(_Card):
	pass

class _Militia(_Card):
	pass

class _Mine(_Card):
	pass

class _Moat(_Card):
	pass

class _Money_lender(_Card):
	pass

class _Remodel(_Card):
	pass

class _Silver(_Card):
	pass

class _Smithy(_Card):
	pass

class _Spy(_Card):
	pass

class _Thief(_Card):
	pass

class _Throne_room(_Card):
	pass

class _Village(_Card):
	pass

class _Witch(_Card):
	pass

class _Curse(_Card):
	pass

class _Woodcutter(_Card):
	pass

class _Workshop(_Card):
	pass

class _Duchy(_Card):
	pass

class _Gardens(_Card):
	pass

class _Province(_Card):
	pass

class _Estate(_Card):
	pass

class _Gold(_Card):
	pass