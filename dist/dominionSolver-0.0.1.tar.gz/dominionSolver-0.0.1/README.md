# executor-engine
Package for reading and analyzing stock data
